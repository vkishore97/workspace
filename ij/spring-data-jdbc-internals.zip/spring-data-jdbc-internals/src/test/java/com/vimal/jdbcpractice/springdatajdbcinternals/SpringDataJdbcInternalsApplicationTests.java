package com.vimal.jdbcpractice.springdatajdbcinternals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJdbcInternalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
