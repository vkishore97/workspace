package com.vimal.jdbcpractice.springdatajdbcinternals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJdbcInternalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJdbcInternalsApplication.class, args);
	}

}
